<p align="center">
  <a href="https://github.com/desiboyz">
    <img src="./assets/Windows_10_Logo.png" alt="Logo">
  </a>

  <h3 align="center">Windows 10 Activator</h3>
  <h4 align="center">💖Support this repo by giving a star. Thanks.</h4>
  
- Methid 1 - [Click here]()
- Method 2 - [Click here]()
- Method 3 - [Click here]()

## Supported Versions.
- Windows 10 Home.
- Windows 10 Professional.
- Windows 10 Enterprise, Enterprise LISB.
- Windows 10 Education.

## How to use ? - Method 1
- Clone or download the repository and unzip it into your PC.
- Open Notepad to create a new file.
- Open windows-activation.txt file and copy code from that to new file and name it with `.bat` extension (for example- file.bat).
- Now right click on `.bat` file and click on `Run as Administrator`.
- During all these steps please connect your PC to your own mobile hotspot not from any proxy server.
- After successful activation restart your PC.

## Method 2

``` 
1. Open CMD as Administrator

2. Paste the following commands into the Cmd: One by one, follow the order.

 cscript slmgr.vbs /ipk "SERIAL NUMBER HERE"
 
 Replace SERIAL NUMBER HER with any of these, according your Windows 10 installation type.
          Home/Core                            TX9XD-98N7V-6WMQ6-BX7FG-H8Q99        
          Home/Core (Country Specific)         PVMJN-6DFY6-9CCP6-7BKTT-D3WVR  
          Home/Core (Single Language)          7HNRX-D7KGG-3K4RQ-4WPJ4-YTDFH  
          Home/Core N                          3KHY7-WNT83-DGQKR-F7HPR-844BM 
          Professional                         W269N-WFGWX-YVC9B-4J6C9-T83GX 
          Professional N                       MH37W-N47XK-V7XM9-C7227-GCQG9 
          Enterprise                           NPPR9-FWDCX-D2C8J-H872K-2YT43 
          Enterprise N                         DPH2V-TTNVB-4X9Q3-TJR4H-KHJW4 
          Education                            NW6C2-QMPVW-D7KKK-3GKT6-VCFB2 
          Education N                          2WH4N-8QGBV-H22JP-CT43Q-MDWWJ 
          Enterprise 2015 LTSB                 WNMTR-4C88C-JK8YV-HQ7T2-76DF9
          Enterprise 2015 LTSB N               2F77B-TNFGY-69QQF-B8YKP-D69TJ 
          Enterprise 2016 LTSB                 DCPHK-NFMTC-H88MJ-PFHPY-QJ4BJ  
          Enterprise 2016 LTSB N               QFFDN-GRT3P-VKWWX-X7T3R-8B639
 
 cscript slmgr.vbs /skms kms.lotro.cc
 
 cscript slmgr.vbs /ato
 ```

## Method 3
Active your windows 10 with KMS key for 6 month

# Active Wondows 10 Pro :

Run all of the commands one by one on cmd as an administrator.

```
slmgr /ipk W269N-WFGWX-YVC9B-4J6C9-T83GX
slmgr /skms kms8.msguides.com
slmgr /ato
slmgr /xpr
```
## All Windows 10 Keys :

```
Home: TX9XD-98N7V-6WMQ6-BX7FG-H8Q99
Home N: 3KHY7-WNT83-DGQKR-F7HPR-844BM
Home Single Language: 7HNRX-D7KGG-3K4RQ-4WPJ4-YTDFH
Home Country Specific: PVMJN-6DFY6-9CCP6-7BKTT-D3WVR
Professional: W269N-WFGWX-YVC9B-4J6C9-T83GX
Professional N: MH37W-N47XK-V7XM9-C7227-GCQG9
Education: NW6C2-QMPVW-D7KKK-3GKT6-VCFB2
Education N: 2WH4N-8QGBV-H22JP-CT43Q-MDWWJ
Enterprise: NPPR9-FWDCX-D2C8J-H872K-2YT43
Enterprise N: DPH2V-TTNVB-4X9Q3-TJR4H-KHJW4
```
